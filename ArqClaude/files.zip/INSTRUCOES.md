# Alterações Realizadas — Digital Library

## Arquivos gerados (substituir os originais)

| Arquivo gerado             | Substitui                          |
|----------------------------|------------------------------------|
| `navbar.html`              | `pages/components/navbar.html`     |
| `TelaHome.html`            | `pages/TelaHome.html`              |
| `dashboard.html`           | `pages/dashboard.html`             |
| `dashboard.css`            | `styles/dashboard.css`             |

---

## ✅ O que foi feito

### 1. Logo no navbar — todas as páginas
O `navbar.html` (componente) agora usa `<img src="../img/logo_navbar.png">` em vez do ícone
`<i class="fa-solid fa-book-open">`. O `TelaHome.html` e `dashboard.html` também foram corrigidos.

**Ação necessária:** nas demais páginas que têm o navbar inline, substitua manualmente:
```html
<!-- ANTES -->
<i class="fa-solid fa-book-open" style="font-size: 30px; color: #fff;"></i>

<!-- DEPOIS -->
<img src="../img/logo_navbar.png" alt="Digital Library" class="logo-img">
```
Páginas afetadas: `TelaCatalogoLivros.html`, `TelaLogin.html`, `TelaCadastrarUser.html`,
`TelaDoLivro.html`, `TelaADDLivro.html`, `TelaUsuariologado.html`.

---

### 2. Cores verdes → azul bebê
Todas as ocorrências de verde (#1d9e75, #5dcaa5, teal) no dashboard foram substituídas
por tons de azul claro (#7aadff, #90bfff, #a0b8f0).

**Ação necessária:** se outros arquivos CSS usarem a variável de verde para destaques
(ex: `sobre.css`, `contato.css`, `SessaoLivros.css`), procure e substitua:
- `#1d9e75` → `#7aadff`
- `#5dcaa5` → `#90bfff`
- `rgba(29,158,117,...)` → `rgba(100,160,255,...)`

---

### 3. Dashboard menos colorido
- Ícones antes verde/âmbar agora usam variações de azul
- Borders dos cards passaram de cores saturadas para azul suave
- Status "ativo" no gráfico e empréstimos recentes: verde → azul bebê
- O vermelho para "atrasado" foi mantido (tem função semântica de alerta)

---

### 4. Login não obrigatório para navegar
O site já funcionava sem login para navegação. O `TelaHome.html` recebeu proteção
no botão "Enviar Mensagem" (contato): só envia se houver sessão ativa.

**Para proteger Reservar/Emprestar:** no arquivo de script da página de livro
(`TelaDoLivro` ou similar), adicione a mesma verificação antes de chamar a ação:
```javascript
const sessao = JSON.parse(
  sessionStorage.getItem('usuario') || localStorage.getItem('usuario') || 'null'
);
if (!sessao) {
  alert('Faça login para reservar ou emprestar um livro.');
  window.location.href = '/BibliotecaSA/pages/TelaLogin.html';
  return;
}
```

---

### 5. Footer aparecendo
O `<div id="footer"></div>` já existia em `TelaHome.html` e `dashboard.html` —
o `include.js` carrega o conteúdo de `components/footer.html` nesse div.

Se o footer não aparecer, verifique:
1. O arquivo existe em `components/footer.html` (caminho relativo à raiz do projeto)
2. O `include.js` é carregado **depois** do `div#footer` no HTML
3. Não há erro de CORS — o site precisa rodar via servidor (não abrir o `.html` direto
   no navegador via `file://`)
